create
    definer = root@localhost function average_wage(DpName varchar(20), Years int) returns decimal(10, 1)
BEGIN
     DECLARE avg_wage DECIMAL(10,1);
     SELECT AVG(NetSal) INTO avg_wage FROM salary WHERE EmployeeID
      =ANY(SELECT  EmployeeID FROM employees WHERE DepartmentID =
      (SELECT DepartmentID FROM departments WHERE DepartmentName =DpName ) ) AND Syear=Years GROUP BY Syear;
      RETURN avg_wage;
    END;

