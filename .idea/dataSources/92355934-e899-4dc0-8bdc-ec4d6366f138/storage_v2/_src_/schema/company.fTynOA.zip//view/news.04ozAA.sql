create definer = root@localhost view news as
select distinct `e`.`EmployeeID`                         AS `EmployeeID`,
                `e`.`Name`                               AS `NAME`,
                `company`.`departments`.`DepartmentName` AS `DepartmentName`,
                `company`.`salary`.`NetSal`              AS `NetSal`
from ((`company`.`employees` `e` join `company`.`departments` on ((`e`.`DepartmentID` = `company`.`departments`.`DepartmentID`)))
         join `company`.`salary` on ((`e`.`EmployeeID` = `company`.`salary`.`EmployeeID`)));

