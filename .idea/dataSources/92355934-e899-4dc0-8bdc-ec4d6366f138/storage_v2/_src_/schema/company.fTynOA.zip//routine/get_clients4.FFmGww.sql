create
    definer = root@localhost procedure get_clients4()
begin
    SELECT * FROM clients;
end;

