create definer = root@localhost trigger com
    before delete
    on employees
    for each row
begin
	delete from salary where employeeID=old.employeeid;
end;

