create definer = root@localhost view member as
select `company`.`employees`.`EmployeeID`       AS `EmployeeID`,
       `company`.`employees`.`Name`             AS `Name`,
       `company`.`departments`.`DepartmentName` AS `DepartmentName`
from `company`.`employees`
         join `company`.`departments`
where (`company`.`departments`.`DepartmentID` = `company`.`employees`.`DepartmentID`);

