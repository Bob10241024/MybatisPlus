create definer = root@localhost view viw_1 as
select `company`.`employees`.`EmployeeID`       AS `employeeid`,
       `company`.`employees`.`Name`             AS `name`,
       `company`.`departments`.`DepartmentName` AS `departmentName`,
       `company`.`employees`.`BasicSal`         AS `BasicSal`
from (`company`.`employees`
         join `company`.`departments`
              on ((`company`.`employees`.`DepartmentID` = `company`.`departments`.`departmentID`)));

