create
    definer = root@localhost procedure get_clients()
begin
    SELECT * FROM clients;
end;

