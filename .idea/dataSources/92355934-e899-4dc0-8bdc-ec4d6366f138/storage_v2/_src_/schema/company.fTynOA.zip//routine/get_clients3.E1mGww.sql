create
    definer = root@localhost procedure get_clients3()
begin
    SELECT * FROM clients;
end;

